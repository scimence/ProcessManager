
package com.sc.processmanager;

import java.util.List;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


// �洢������Ϣ
class processInfo
{
	public Drawable appIcon;  		// Ӧ�ó���ͼ��
	public String appName;    		// Ӧ������
	public String pkgName;    		// Ӧ�ð���
	
	public int pid;  				// ��Ӧ�ó������ڵĽ��̺�
	public String processName;  	// ��Ӧ�ó������ڵĽ�����
	
	public processInfo()
	{}
}


class processInfoObj
{
	ImageView appIcon;
	TextView appName;
	TextView packageName;
	TextView processId;
	TextView processName;
	
	public processInfoObj(View view)
	{
		this.appIcon = (ImageView) view.findViewById(R.id.imageIcon);
		this.appName = (TextView) view.findViewById(R.id.textAppName);
		this.packageName = (TextView) view.findViewById(R.id.textPackageName);
		this.processId = (TextView) view.findViewById(R.id.textProcessId);
		this.processName = (TextView) view.findViewById(R.id.textProcessName);
	}
	
	public void setInfo(processInfo info)
	{
		appIcon.setImageDrawable(info.appIcon);
		appName.setText(info.appName);
		packageName.setText(info.pkgName);
		processId.setText(info.pid + "");
		processName.setText(info.processName);
	}
}


// ������Ϣ�б������䣬�ṩ��listView���Զ���view
public class ProcessInfoAdapter extends BaseAdapter
{
	private List<processInfo> processInfos = null;	// �洢������Ϣ
	LayoutInflater infater = null;
	
	public ProcessInfoAdapter(Context context, List<processInfo> processInfos)
	{
		infater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.processInfos = processInfos;
	}
	
	// ��ȡ�б�����Ŀ
	public int getCount()
	{
		System.out.println("ϵͳ�������еĽ�����Ŀ��" + processInfos.size());
		return processInfos.size();
	}
	
	// ��ȡ�б�����Ϣ
	public Object getItem(int position)
	{
		return processInfos.get(position);
	}
	
	public long getItemId(int position)
	{
		return 0;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		// System.out.println("getView at " + position);
		
		View view;
		processInfoObj obj;
		
		if (convertView == null || convertView.getTag() == null)
		{
			view = infater.inflate(R.layout.process_item, null);
			obj = new processInfoObj(view);
			view.setTag(obj);
		}
		else
		{
			view = convertView;
			obj = (processInfoObj) convertView.getTag();
		}
		
		processInfo info = (processInfo) getItem(position);
		obj.setInfo(info);
		
		return view;
	}
	
}
